# Checklist Light Copy. Verificação Rápida

> Aplique este checklist a TODA copy gerada, frase por frase, antes de mostrar ao usuário.
> Se qualquer item falhar: reescreva o trecho, depois verifique novamente.

---

## 12 Proibições Absolutas

| # | Proibição | Como corrigir |
|---|---|---|
| 1 | Travessão (—) em qualquer texto | Substitua por vírgula, ponto, dois pontos, parênteses ou reescreva a frase |
| 2 | Ponto de exclamação (!) | Substitua por ponto final ou reescreva |
| 3 | Pergunta no gancho ou primeira linha | Transforme em afirmação direta |
| 4 | Estrutura "Não é X. É Y." | Afirme diretamente o que é, sem negação |
| 5 | Promessa vaga sem dado concreto | Adicione número, prazo ou situação específica |
| 6 | "mesmo que" ou "sem precisar" como muleta | Substitua por argumento real e direto |
| 7 | Erros de português ou acentuação | Revise concordância verbal/nominal, acentuação e pontuação |
| 8 | Lero-lero. palavras genéricas que soam bem mas não dizem nada ("padrão interno", "segurança interna", "caminhos terapêuticos", "processos emocionais", "reconectar com a sensibilidade", "jornada de autoconhecimento") | Teste. dá pra trocar por outra palavra genérica do nicho sem mudar o sentido? Se sim, substitua por dado concreto, cena real ou argumento específico |
| 9 | Copy sem tese. descreve o problema sem argumentar por que ele existe | Adicione a causa. "Você procrastina" vira "Você procrastina porque seu cérebro foi programado para ação imediata e não para acumular reservas" |
| 10 | Sigla ou nome de técnica sem explicação no mesmo parágrafo | Insira explicação entre parênteses ou reescreva sem a sigla |
| 11 | Depoimento que só elogia sem resultado concreto ("material lindo", "mudou minha vida", "professora incrível") | Sinalizar para substituição. Depoimento que converte. antes + resultado específico + número ou prazo |
| 12 | Venda só da promessa sem benefício. defende só a transformação técnica sem a consequência emocional ou financeira | Adicionar o benefício. o que muda na vida da pessoa depois do resultado (fila de espera, reconhecimento, faturamento, tempo livre) |

---

## Exemplos de correção

- ❌ "Transforme sua vida — sem esforço!"
  ✅ "Veja como pessoas com rotina cheia reorganizaram suas finanças em 30 dias."

- ❌ "Você quer parar de sofrer?"
  ✅ "Existe um padrão que faz a maioria das pessoas sabotar seus resultados."

- ❌ "Não é um curso. É uma transformação."
  ✅ "É um programa de 8 semanas com acompanhamento individual."

- ❌ "Reconecte com sua segurança interna através de caminhos terapêuticos."
  ✅ "Em 4 semanas, você para de adiar a conversa difícil que está travando sua carreira há meses."

- ❌ Copy só descritiva. "Você se sente presa no ciclo de sabotar."
  ✅ Copy com tese. "Você se sabota porque seu cérebro interpreta como ameaça qualquer situação nova sem precedente na sua memória."

---

## Produto não aparece no lead

O produto não aparece no lead. Nada de "curso", "treinamento", "compre", nome do método, nome do produto ou sigla do programa no início da copy. Isso vale para os 4 primeiros blocos da página de vendas (Hero, Dor, Prova social inicial, CTA intermediário). O lead fala sobre a dor, o desejo ou a transformação do leitor. O nome do produto/método aparece pela primeira vez no **Bloco 05 — Método**.

---

## Regras adicionais de argumento e estrutura

- Para produtos de desenvolvimento pessoal ou nichos abstratos. a especificidade não precisa estar na promessa, pode estar na história. Uma história real e específica converte mais que qualquer promessa polida.
- A seção de autoridade precisa da jornada de origem com fragilidade. o que o criador enfrentou antes de ter o método, qual foi a virada, por que isso existe.
- Método de low ticket (até R$ 97) deve ser simples e imediato. resultado de hoje para amanhã, sem método de 8 passos elaborados.
- Headline em toda seção. seção sem headline é seção invisível.
